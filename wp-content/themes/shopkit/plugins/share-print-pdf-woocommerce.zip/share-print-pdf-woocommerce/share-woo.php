<?php
/*
Plugin Name: Share, Print and PDF Products for WooCommerce
Plugin URI: http://www.mihajlovicnenad.com/product-filter
Description: Share, Print and PDF Products for Woocommerce! It is going viral! - mihajlovicnenad.com
Author: Mihajlovic Nenad
Version: 1.4.0
Author URI: http://www.mihajlovicnenad.com
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( !class_exists( 'WC_Share_Print_PDF_Init' ) ) :

	final class WC_Share_Print_PDF_Init {

		public static $version = '1.4.0';

		protected static $_instance = null;

		public static function instance() {

			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		public function __construct() {
			do_action( 'wcmnspp_loading' );

			$this->includes();

			$this->init_hooks();

			do_action( 'wcmnspp_loaded' );
		}

		private function init_hooks() {
			add_action( 'init', array( $this, 'init' ), 0 );
		}

		private function is_request( $type ) {
			switch ( $type ) {
				case 'admin' :
					return is_admin();
				case 'ajax' :
					return defined( 'DOING_AJAX' );
				case 'cron' :
					return defined( 'DOING_CRON' );
				case 'frontend' :
					return ( ! is_admin() || defined( 'DOING_AJAX' ) ) && ! defined( 'DOING_CRON' );
			}
		}

		public function includes() {

			if ( $this->is_request( 'admin' ) ) {
				include_once ( 'lib/spp-settings.php' );

				$purchase_code = get_option( 'wc_settings_spp_update_code', '' );
				if ( $purchase_code ) {
					require 'lib/update/plugin-update-checker.php';
					$pf_check = PucFactory::buildUpdateChecker(
						'http://mihajlovicnenad.com/envato/get_json.php?p=13127221&k=' . $purchase_code,
						__FILE__
					);
				}

			}

			if ( $this->is_request( 'frontend' ) ) {
				$this->frontend_includes();
			}

		}

		public function frontend_includes() {
			include_once( 'lib/spp-frontend.php' );
		}

		public function init() {

			do_action( 'before_wcmnspp_init' );

			$this->load_plugin_textdomain();

			do_action( 'after_wcmnspp_init' );

		}

		public function load_plugin_textdomain() {

			$domain = 'wcsppdf';
			$dir = untrailingslashit( WP_LANG_DIR );
			$locale = apply_filters( 'plugin_locale', get_locale(), $domain );

			if ( $loaded = load_textdomain( $domain, $dir . '/plugins/' . $domain . '-' . $locale . '.mo' ) ) {
				return $loaded;
			}
			else {
				load_plugin_textdomain( $domain, FALSE, basename( dirname( __FILE__ ) ) . '/lang/' );
			}

		}

		public function plugin_url() {
			return untrailingslashit( plugins_url( '/', __FILE__ ) );
		}

		public function plugin_path() {
			return untrailingslashit( plugin_dir_path( __FILE__ ) );
		}

		public function plugin_basename() {
			return untrailingslashit( plugin_basename( __FILE__ ) );
		}

		public function ajax_url() {
			return admin_url( 'admin-ajax.php', 'relative' );
		}

		public static function version_check( $version = '3.0.0' ) {
			if ( class_exists( 'WooCommerce' ) ) {
				global $woocommerce;
				if( version_compare( $woocommerce->version, $version, ">=" ) ) {
					return true;
				}
			}
			return false;
		}

		public function version() {
			return self::$version;
		}

	}

	function Wcmnspp() {
		return WC_Share_Print_PDF_Init::instance();
	}

	WC_Share_Print_PDF_Init::instance();

endif;

?>