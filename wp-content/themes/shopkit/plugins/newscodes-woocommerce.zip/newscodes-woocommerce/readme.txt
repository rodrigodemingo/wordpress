Newscodes - News, Magazine and Blog Elements for Wordpress! WooCommerce Extension!
by Mihajlovicnenad.com - https://mihajlovicnenad.com

Read documentation for more information! http://mihajlovicnenad.com/newscodes/documentation/