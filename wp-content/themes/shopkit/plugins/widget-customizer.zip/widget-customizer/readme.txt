Widget and Sidebar Customizer for Wordpress!
by Mihajlovicnenad.com - https://mihajlovicnenad.com

Read documentation for more information! https://mihajlovicnenad.com/widget-customizer/documentation/