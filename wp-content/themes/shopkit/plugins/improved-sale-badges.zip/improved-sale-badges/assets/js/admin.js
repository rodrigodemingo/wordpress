(function($){

	"use strict";

	var callIvpa;

	$('#wc_settings_isb_special_text').on('change keyup paste', function() {
		if ( $('#wc_settings_isb_special').val() == '' ) {
			return false;
		}
		if(callIvpa) {
			clearTimeout(callIvpa);
		}
		callIvpa = setTimeout(call_isb, 500);
	});

	var blockChange = false;
	$(document).on('change', 'select[id^="wc_settings_isb"]', function() {
		if ( blockChange === true ) {
			return false;
		}
		call_isb();
	});

	function set_isb(response) {

		if ( typeof response.style !== 'undefined' ) {
			blockChange = true;
			$('#wc_settings_isb_style').val(response.style).change();
			$('#wc_settings_isb_color').val(response.color).change();
			$('#wc_settings_isb_position').val(response.position).change();
			$('#wc_settings_isb_special_text').val(response.special_text);
			blockChange = false;
			$('#wc_settings_isb_special').val(response.special).change();
		}
		else {
			$.alert('Error!');
		}

	}

	function call_isb() {

		var data = {
			action: 'isb_respond',
			data: {
				'isb_style': $('#wc_settings_isb_style').val(),
				'isb_color': $('#wc_settings_isb_color').val(),
				'isb_position': $('#wc_settings_isb_position').val(),
				'isb_special': $('#wc_settings_isb_special').val(),
				'isb_special_text': $('#wc_settings_isb_special_text').val()
			}
		};

		if ( $('#wc_settings_isb_preset').length>0 ) {
			data.data.isb_preset = $('#wc_settings_isb_preset').val();
		}

		$.when( call_ajax( data ) ).done( function(response) {
			$('#isb_preview').empty().append(response);
		});

		return false;

	}

	function save_isb(name) {

		var data = {
			action: 'isb_respond',
			data: {
				'action': 'save',
				'name': name,
				'isb_style': $('#wc_settings_isb_style').val(),
				'isb_color': $('#wc_settings_isb_color').val(),
				'isb_position': $('#wc_settings_isb_position').val(),
				'isb_special': $('#wc_settings_isb_special').val(),
				'isb_special_text': $('#wc_settings_isb_special_text').val()
			}
		};

		$.when( call_ajax( data ) ).done( function(response) {
			$.alert({
				title: 'Success',
				content:'Preset successfully saved!'
			});

			if ( typeof response.slug !== 'undefined' && $('.isb_filter_presets:first').find('option[value="'+response.slug+'"]').length == 0 ) {
				$('.isb_filter_presets').append('<option value="'+response.slug+'">'+response.name+'</option>');
			}
		});

		return false;

	}

	function call_ajax(data) {
		return $.ajax({
			type: 'POST',
			url: isb.ajax,
			data: data,
			success: function(response) {

			},
			error: function() {
				$.alert('Error!');
			}
		});
	}

	function check_default() {
		if( $('#isb-presets').val() == '' ) {
			return false;
		}
		return true;
	}

	$(document).on( 'click', '#isb-save-preset', function() {

		var makeConfirm = false;
		if ( check_default() === false ) {
			makeConfirm = '';
		}
		else {
			makeConfirm = $('#isb-presets option[value="'+$('#isb-presets').val()+'"]').text();
		}

		$.confirm({
			title: 'Enter preset name',
			content: '' +
				'<form action="" class="formName">' +
				'<div class="form-group">' +
				'<input type="text" placeholder="Preset name" class="name form-control" required value="'+makeConfirm+'" />' +
				'</div>' +
				'</form>',
			buttons: {
				formSubmit: {
					text: 'Save',
					btnClass: 'btn-blue',
					action: function () {

						var name = this.$content.find('.name').val();
						if(!name){
							$.alert('provide a valid name');
							return false;
						}
						save_isb(name);

					}
				},
				cancel: function () {

				},
			},
			onContentReady: function () {
				var jc = this;
				this.$content.find('form').on('submit', function (e) {
					e.preventDefault();
					jc.$$formSubmit.trigger('click');
				});
			}
		});

		return false;

	});

	$(document).on( 'click', '#isb-load-preset', function() {
		if ( check_default() === false ) {
			location.reload();
		}
		else {
			var data = {
				action: 'isb_respond',
				data: {
					'action': 'load',
					'name': $('#isb-presets').val()
				}
			};

			$.when( call_ajax( data ) ).done( function(response) {
				set_isb(response);
			});

			return false;
		}
		
	});

	$(document).on( 'click', '#isb-delete-preset', function() {

		if ( check_default() === false ) {
			$.alert({
				title: 'Error',
				content:'Default preset cannot be deleted'
			});
		}
		else {
			var data = {
				action: 'isb_respond',
				data: {
					'action': 'delete',
					'name': $('#isb-presets').val()
				}
			};

			$.when( call_ajax( data ) ).done( function(response) {
				$.alert({
					title: 'Success',
					content:'Preset successfully deleted!'
				});

				if ( typeof response.slug !== 'undefined' ) {
					$('.isb_filter_presets option[value="'+response.slug+'"]').remove();
				}
			});

			return false;
		}

		return false;

	});

	$(document).on( 'click', '#isb-save-default', function() {
		$('#mainform input[type="submit"]').trigger('click');
	});


	$(document).on( 'click', '#isb_overrides .isb_remove', function() {
		$(this).closest('.isb_override').remove();
	});

	$(document).on( 'click', '#isb_overrides .isb_add', function() {

		var wrap = $(this).closest('p');
		var controls = wrap.find('.isb_overrides');

		var preset = wrap.find('.isb_presets').val();

		if ( preset == '' || controls.find('.isb_id[data-id="'+wrap.find('.isb_tax_select').val()+'"]').length>0 ) {
			return false;
		}

		var id = wrap.find('.isb_tax_select').val();

		controls.append('<span class="isb_override">Term : <span class="isb_id" data-id="'+id+'">'+wrap.find('.isb_tax_select option[value="'+id+'"]').text()+'</span> Preset : <span class="isb_preset" data-preset="'+preset+'">'+wrap.find('option[value="'+preset+'"]').text()+'</span><span class="isb_remove">Remove</span></span>');
	});

	$(document).on( 'click', '#isb_save_overrides', function() {

		var overrides = {
			'featured': '',
			'new': {},
			'product_tag': {},
			'product_cat': {},
			set: true
		};

		if ( $('#isb_overrides .featured select.isb_presets').val() !== '' ) {
			overrides.set = true;
			overrides.featured = $('#isb_overrides .featured select.isb_presets').val();
		}

		if ( $('#isb_overrides .new select.isb_presets').val() !== '' ) {
			overrides.set = true;
			overrides.new = {
				'days': $('#isb_overrides .new input.isb_days').val(),
				'preset': $('#isb_overrides .new select.isb_presets').val()
			};
		}

		if ( $('#isb_overrides .product_tag .isb_override').length > 0 ) {
			overrides.set = true;
			$('#isb_overrides .product_tag .isb_override').each( function(){
				overrides.product_tag[$(this).find('.isb_id').attr('data-id')] = $(this).find('.isb_preset').attr('data-preset');
			});
		}

		if ( $('#isb_overrides .product_cat .isb_override').length > 0 ) {
			overrides.set = true;
			$('#isb_overrides .product_cat .isb_override').each( function(){
				overrides.product_cat[$(this).find('.isb_id').attr('data-id')] = $(this).find('.isb_preset').attr('data-preset');
			});
		}

		var data = {
			action: 'isb_respond',
			data: {
				'action': 'overrides',
				'overrides': overrides
			}
		};

		/*if ( typeof data.data.overrides.set == 'undefined' ) {
			$.alert({
				title: 'Error',
				content:'Nothing to save!'
			});
			return false;
		}*/

		$.when( call_ajax( data ) ).done( function(response) {
			$.alert({
				title: 'Success',
				content:'Overrides saved!'
			});
		});

		return false;
	});

	function toggleIsbTab() {
		if ( $('#wc_settings_isb_preset').val() == '' ) {
			$('.form-field.isb_no_preset').show();
		}
		else {
			$('.form-field.isb_no_preset').hide();
		}
	}

	if ( $('#isb_tab').length>0 ) {
		
		$(document).ready(function() {
			toggleIsbTab();
		});

		$(document).on('change', $('#wc_settings_isb_preset'), function() {
			toggleIsbTab();
		});
	}

})(jQuery);